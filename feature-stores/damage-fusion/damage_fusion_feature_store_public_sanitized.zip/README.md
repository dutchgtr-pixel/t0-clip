# Fusion Store (Damage Fusion v2) — Certified Package

This bundle contains:

1) Full documentation (`docs/FUSION_STORE_FULL_DOCUMENTATION.md`)
2) All SQL required to (re)create:
   - `ml.v_damage_fusion_features_v2`
   - `ml.v_damage_fusion_features_v2_scored`
   - Certification entrypoint + guarded view
   - Registry certification functions/procedures
   - Viewdef and dataset baselines
3) Optional strict T0/SLA-gated materialization example (from your remediation patterns)

## Expected prerequisites
This package assumes you already have the audit framework installed:
- `audit.t0_cert_registry`
- `audit.t0_viewdef_baseline`
- `audit.t0_dataset_hash_baseline`
- `audit.dataset_sha256(regclass, date, int)`
- `audit.require_certified_strict(text, interval)`

If any of those are missing, install your existing T0 certification framework first (same one used for socio_market and device_meta).

## Recommended execution order (psql)
Run the SQL files in order:

1. sql/01_create_fusion_views_v2.sql
2. sql/02_create_cert_entrypoint_and_guard.sql
3. sql/03_baseline_viewdefs.sql
4. sql/04_baseline_dataset_hashes_365.sql
5. sql/05_cert_functions.sql
6. sql/06_run_certification.sql

After that, your trainer should use:
- `--fusion_features_view ml.v_damage_fusion_features_v2_scored_train_v`

## Files copied from the original working system
For completeness the original upstream references are included:
- docs/REFERENCE__Create_Improved_Fusion_View_v2.txt
- docs/REFERENCE__Damage_Fusion_Feature_Store_Documentation.txt
